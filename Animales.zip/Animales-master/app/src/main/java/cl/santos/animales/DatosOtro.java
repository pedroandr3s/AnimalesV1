package cl.santos.animales;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class DatosOtro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_otro);

        Button volverButton = findViewById(R.id.Volver);

        volverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Crear un Intent para volver al MainActivity
                Intent intent = new Intent(DatosOtro.this, MainActivity.class);
                startActivity(intent);
                // Finalizar la actividad actual si no quieres volver atrás desde MainActivity
                finish();
            }
        });
        Button botonAlimento = findViewById(R.id.Alimento);
        final LinearLayout cantidadLayout = findViewById(R.id.Cantidad);

        botonAlimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Hacer visible el LinearLayout "Cantidad"
                cantidadLayout.setVisibility(View.VISIBLE);
            }
        });

    }
}
